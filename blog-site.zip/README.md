# Blog con Entradas Libres

Un blog colaborativo para la clase de English 2 donde cualquier persona puede publicar artículos.

## Características

- Publicación de artículos con formato HTML
- Categorización de artículos
- Visualización de artículos individuales
- Eliminación de artículos
- Persistencia de datos en el servidor

## Requisitos

- Node.js 14.x o superior
- npm o yarn

## Instalación Local

1. Clona este repositorio:
